// Developer smoke test: runs the actual browser code against small DOM stubs in Node.
// Run: node smoke-test.js (no external dependencies required).
const vm=require('vm'),fs=require('fs'),assert=require('assert');
const root='app/src/main/assets/app.js';
const els=new Map();
class FakeEl{
 constructor(id){this.id=id;this.value='';this.checked=false;this.style={};this.classList={add(){},remove(){},toggle(){},contains(){return false;}};this.innerHTML='';this.textContent='';this.scrollTop=0;this.scrollHeight=0;}
}
const doc={documentElement:new FakeEl('html'),getElementById(id){if(!els.has(id))els.set(id,new FakeEl(id));return els.get(id);},querySelectorAll(){return[];},createElement(){return new FakeEl('tmp');},body:{appendChild(){} }};
const stored={};let lastToast='';
const context={document:doc,window:{open(){},navigator:{},getSpeechRecognition(){},localStorage:null},localStorage:{getItem(k){return stored[k]||null;},setItem(k,v){stored[k]=v;}},navigator:{clipboard:{writeText:async()=>{}}},URL:{createObjectURL(){return 'blob:mock';},revokeObjectURL(){}},Blob:class{},Date,console,setTimeout(fn){return 1;},clearTimeout(){},confirm(){return true;},Math};
context.window.navigator=context.navigator;
vm.createContext(context);
vm.runInContext(fs.readFileSync(root,'utf8'),context);
const V=context.window.Voxa;
assert.deepEqual(Object.entries(V.getCounts()).map(x=>x[1]),[0,0,0,0,0,0]);
V.showImport();doc.getElementById('importTitle').value='Local shop discussion';doc.getElementById('importKind').value='WhatsApp export';doc.getElementById('importText').value='18/10/26, 09:45 - Customer: do you have dresses?\n18/10/26, 10:01 - Seller: cotton suits PKR 2400\n18/10/26, 10:12 - Customer: cotton suits price please?';doc.getElementById('importConsent').checked=true;V.saveImport();
assert.equal(V.getCounts().sources,1,'source imported');
doc.getElementById('postTopic').value='Cotton dresses from Rs 2,400';doc.getElementById('postTone').value='professional';doc.getElementById('postPlatform').value='Facebook';doc.getElementById('postSource').value='';V.generatePost();
assert.equal(V.getCounts().drafts,1,'draft generated');assert.ok(doc.getElementById('postEditor').value.includes('Cotton dresses'));
V.openTaskModal();doc.getElementById('taskName').value='Daily campaign';doc.getElementById('taskTrigger').value='manual';doc.getElementById('taskTime').value='09:00';doc.getElementById('taskGoal').value='Cotton suits';V.saveTask();
assert.equal(V.getCounts().tasks,1,'user-built task saved');
const before=V.getCounts().drafts;const t=JSON.parse(stored.voxaflow_state_v1).tasks[0];V.runTask(t.id);assert.ok(V.getCounts().drafts>before,'workflow created a draft');
V.openLeadModal();doc.getElementById('leadName').value='Shop A';doc.getElementById('leadCity').value='Islamabad';doc.getElementById('leadCategory').value='Garments';doc.getElementById('leadPhone').value='03000000000';doc.getElementById('leadWebsite').value='';doc.getElementById('leadAddress').value='Market';doc.getElementById('leadNotes').value='Allowed research';doc.getElementById('leadPermission').checked=true;V.saveLead();
assert.equal(V.getCounts().leads,1,'lead saved');
V.submitCommand('How many leads do I have?');assert.ok(JSON.parse(stored.voxaflow_state_v1).chat.length>1,'assistant message stored');
V.openProductModal();doc.getElementById('productName').value='Cotton Suit';doc.getElementById('productPrice').value='2200';doc.getElementById('productStock').value='9';doc.getElementById('productCategory').value='Apparel';doc.getElementById('productDescription').value='Verified item';V.saveProduct('');assert.equal(V.getCounts().products,1,'catalog product saved');
V.openOrderModal();doc.getElementById('orderCustomer').value='Order 001';doc.getElementById('orderItem').value='Cotton Suit';doc.getElementById('orderQuantity').value='2';doc.getElementById('orderPrice').value='2200';doc.getElementById('orderProduct').value='';doc.getElementById('orderStatus').value='Completed';doc.getElementById('orderNotes').value='Delivered';V.saveOrder('');assert.equal(V.getCounts().orders,1,'order saved');
console.log('PASS VoxaFlow smoke test: sources, analysis, drafts, custom workflows, leads, chat, persistence.');
