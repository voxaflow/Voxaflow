package com.voxaflow.commerce;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("workflow_title");
        if (title == null) title = "Your VoxaFlow workflow";
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channel = "voxaflow_workflows";
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(new NotificationChannel(channel, "Workflow reminders", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent tap = PendingIntent.getActivity(context, 44, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(context, channel)
                .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
                .setContentTitle("Workflow ready: " + title)
                .setContentText("Open VoxaFlow to review and run the task.")
                .setContentIntent(tap).setAutoCancel(true).build();
        try { manager.notify(("workflow_" + intent.getStringExtra("workflow_id")).hashCode(), notification); }
        catch (SecurityException ignored) { }
    }
}
