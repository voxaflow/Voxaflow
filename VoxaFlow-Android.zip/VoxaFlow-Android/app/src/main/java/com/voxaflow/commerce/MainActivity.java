package com.voxaflow.commerce;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 451;
    private static final int IMPORT_REQUEST = 452;
    private static final int PHOTO_REQUEST = 453;
    private static final int EXPORT_REQUEST = 454;
    private WebView webView;
    private TextToSpeech tts;
    private Uri selectedPhoto;
    private String exportPayload = "";
    private String incomingText;
    private boolean webReady;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xff080d1d);
        getWindow().setNavigationBarColor(0xff0b1123);
        prefs = getSharedPreferences("voxaflow_secure_local", MODE_PRIVATE);
        incomingText = textFromShare(getIntent());
        webView = new WebView(this);
        webView.setBackgroundColor(0xff090f20);
        webView.setVerticalScrollBarEnabled(false);
        webView.setFitsSystemWindows(true);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                webReady = true;
                deliverSharedText();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) && "android_asset".equals(uri.getPathSegments().isEmpty() ? "" : uri.getPathSegments().get(0))) return false;
                openExternalUrl(uri.toString());
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        tts = new TextToSpeech(this, result -> { });
    }

    private String textFromShare(Intent intent) {
        if (intent != null && Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            return intent.getStringExtra(Intent.EXTRA_TEXT);
        }
        return null;
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        incomingText = textFromShare(intent);
        deliverSharedText();
    }

    private void deliverSharedText() {
        if (!webReady || incomingText == null || incomingText.isEmpty()) return;
        String share = incomingText;
        incomingText = null;
        sendEvent("shared", share);
    }

    private void sendEvent(String type, String text) {
        JSONObject event = new JSONObject();
        try {
            event.put("type", type);
            event.put("text", text == null ? "" : text);
        } catch (Exception ignore) { }
        String js = "window.VoxaNativeEvent && window.VoxaNativeEvent(" + event.toString() + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private void openExternalUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return;
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) { toast("Could not open this link"); }
    }

    private void toast(String text) { runOnUiThread(() -> Toast.makeText(this, text, Toast.LENGTH_SHORT).show()); }

    private PendingIntent alarmIntent(String id, String title) {
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.setAction("com.voxaflow.WORKFLOW_" + id);
        intent.putExtra("workflow_id", id);
        intent.putExtra("workflow_title", title);
        return PendingIntent.getBroadcast(this, id.hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    class AppBridge {
        @JavascriptInterface public String getState() { return prefs.getString("app_state", ""); }

        @JavascriptInterface public void saveState(String json) {
            if (json != null && json.length() <= 4_000_000) prefs.edit().putString("app_state", json).apply();
        }

        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> openExternalUrl(url));
        }

        @JavascriptInterface public void openMap(String search) {
            String url = "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(search);
            runOnUiThread(() -> openExternalUrl(url));
        }

        @JavascriptInterface public void shareText(String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(send, "Share with…"));
            });
        }

        @JavascriptInterface public void sharePost(String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                if (selectedPhoto != null) {
                    send.setType("image/*");
                    send.putExtra(Intent.EXTRA_STREAM, selectedPhoto);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } else send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(send, "Choose where to share"));
            });
        }

        @JavascriptInterface public void pickDocument() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "text/csv", "application/zip", "application/x-zip-compressed"});
                startActivityForResult(intent, IMPORT_REQUEST);
            });
        }

        @JavascriptInterface public void pickPhoto() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("image/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, PHOTO_REQUEST);
            });
        }

        @JavascriptInterface public void clearPhoto() {
            selectedPhoto = null;
            sendEvent("photo", "");
        }

        @JavascriptInterface public void voiceInput(String language) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur".equals(language) ? "ur-PK" : "en-PK");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to VoxaFlow");
                    startActivityForResult(intent, VOICE_REQUEST);
                } catch (Exception e) {
                    sendEvent("error", "Voice recognition is unavailable on this device");
                }
            });
        }

        @JavascriptInterface public void speak(String content, String language) {
            runOnUiThread(() -> {
                if (tts == null) return;
                tts.setLanguage("ur".equals(language) ? new Locale("ur", "PK") : new Locale("en", "PK"));
                tts.speak(content, TextToSpeech.QUEUE_FLUSH, null, "voxaflow_response");
            });
        }

        @JavascriptInterface public void copyText(String content) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("VoxaFlow", content));
                toast("Copied to clipboard");
            });
        }

        @JavascriptInterface public void exportFile(String name, String mime, String content) {
            runOnUiThread(() -> {
                exportPayload = content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime);
                intent.putExtra(Intent.EXTRA_TITLE, name);
                startActivityForResult(intent, EXPORT_REQUEST);
            });
        }

        @JavascriptInterface public void scheduleDaily(String id, String name, int hour, int minute) {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 989);
                    }
                    Calendar when = Calendar.getInstance();
                    when.set(Calendar.HOUR_OF_DAY, Math.max(0, Math.min(23, hour)));
                    when.set(Calendar.MINUTE, Math.max(0, Math.min(59, minute)));
                    when.set(Calendar.SECOND, 0);
                    if (when.getTimeInMillis() <= System.currentTimeMillis()) when.add(Calendar.DAY_OF_MONTH, 1);
                    AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                    alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(),
                            AlarmManager.INTERVAL_DAY, alarmIntent(id, name));
                } catch (Exception e) { sendEvent("error", "Unable to schedule reminder"); }
            });
        }

        @JavascriptInterface public void cancelDaily(String id) {
            runOnUiThread(() -> {
                AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                alarmManager.cancel(alarmIntent(id, ""));
            });
        }
    }

    private String readTextOrZip(Uri uri) throws Exception {
        String mime = getContentResolver().getType(uri);
        boolean zip = (mime != null && mime.contains("zip")) || uri.toString().toLowerCase().endsWith(".zip");
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) return "";
            if (zip) {
                try (ZipInputStream archive = new ZipInputStream(input)) {
                    ZipEntry entry;
                    while ((entry = archive.getNextEntry()) != null) {
                        if (!entry.isDirectory() && entry.getName().toLowerCase().endsWith(".txt"))
                            return boundedRead(archive, 1_800_000);
                    }
                }
                return "No text file found in the WhatsApp ZIP export.";
            }
            return boundedRead(input, 1_800_000);
        }
    }

    private String boundedRead(InputStream input, int limit) throws Exception {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] bytes = new byte[8192];
        int n;
        while ((n = input.read(bytes)) != -1) {
            if (buffer.size() + n > limit) throw new IllegalStateException("File too large. Maximum 1.8 MB of text.");
            buffer.write(bytes, 0, n);
        }
        return buffer.toString("UTF-8");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && intent != null) {
            java.util.ArrayList<String> lines = intent.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (lines != null && !lines.isEmpty()) sendEvent("voice", lines.get(0));
        }
        if (requestCode == IMPORT_REQUEST && resultCode == RESULT_OK && intent != null && intent.getData() != null) {
            try { sendEvent("import", readTextOrZip(intent.getData())); }
            catch (Exception e) { sendEvent("error", "Import failed: " + e.getMessage()); }
        }
        if (requestCode == PHOTO_REQUEST && resultCode == RESULT_OK && intent != null && intent.getData() != null) {
            try {
                selectedPhoto = intent.getData();
                final int flags = intent.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(selectedPhoto, flags);
                try (InputStream input = getContentResolver().openInputStream(selectedPhoto)) {
                    Bitmap source = BitmapFactory.decodeStream(input);
                    if (source == null) throw new Exception("Cannot preview this image");
                    int max = Math.max(source.getWidth(), source.getHeight());
                    float scale = Math.min(1, 400f / max);
                    Bitmap preview = Bitmap.createScaledBitmap(source, Math.round(source.getWidth() * scale), Math.round(source.getHeight() * scale), true);
                    ByteArrayOutputStream result = new ByteArrayOutputStream();
                    preview.compress(Bitmap.CompressFormat.JPEG, 70, result);
                    sendEvent("photo", "data:image/jpeg;base64," + Base64.encodeToString(result.toByteArray(), Base64.NO_WRAP));
                    if (preview != source) preview.recycle();
                    source.recycle();
                }
            } catch (Exception e) { sendEvent("error", "Photo selection failed: " + e.getMessage()); }
        }
        if (requestCode == EXPORT_REQUEST && resultCode == RESULT_OK && intent != null && intent.getData() != null) {
            try (OutputStream output = getContentResolver().openOutputStream(intent.getData())) {
                if (output != null) {
                    output.write(exportPayload.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                    toast("Saved successfully");
                }
            } catch (Exception e) { sendEvent("error", "Export failed: " + e.getMessage()); }
            exportPayload = "";
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.Voxa && window.Voxa.back()", null);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
