/* VoxaFlow — mobile-first, local-first commerce workspace.
   No telemetry, authentication server, scraping, password collection, or unattended social posting.
   Modern browsers can open this file as a functional offline demo.
*/
(function () {
'use strict';
const NATIVE = typeof window.AndroidBridge !== 'undefined' ? window.AndroidBridge : null;
const STORE = 'voxaflow_state_v1';
const $ = id => document.getElementById(id);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const escape = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const nl = s => String(s || '').replace(/\s+/g, ' ').trim();
const icon = name => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const short = (s, n=130) => (s.length > n ? s.slice(0,n).trimEnd()+'…' : s);
const safeDate = () => new Date().toLocaleDateString('en-PK',{day:'numeric',month:'short',year:'numeric'});
const timestamp = () => new Date().toISOString();
const fmtDate = d => { try { return new Date(d).toLocaleDateString('en-PK',{day:'numeric',month:'short'}); } catch(_) { return ''; } };
const defaults = () => ({schema:1,sources:[],drafts:[],tasks:[],leads:[],products:[],orders:[],activity:[],chat:[{who:'assistant',text:'Hello! I’m Voxa, your local commerce command assistant. I can help you draft posts, analyze imported chats, organize leads and run custom workflows. Try saying “Create a Facebook post” or “Find garment shops in Lahore”.'}],settings:{language:'en',speak:false,theme:'dark'}});
let state = defaults();
let screen = 'home', taskFilter = 'all', photoPreview = '', pendingToast;
let editingTaskId = null, editingLeadId = null, modalSteps = [];
let workflowRunLock = false;
const types = [
  {id:'analyze',name:'Analyze latest imported source',hint:'Extract keywords and a safe, anonymous summary'},
  {id:'draft',name:'Create a draft post',hint:'Write a caption using supplied topic or source themes'},
  {id:'productpost',name:'Create post for a catalog product',hint:'Use the most recently added product name and price'},
  {id:'save',name:'Save a research note',hint:'Store a short summary in your source library'},
  {id:'maps',name:'Search Google Maps',hint:'Open a search in Google Maps'},
  {id:'share',name:'Review and share a draft',hint:'Open Android share sheet; publishing requires your tap'},
  {id:'copy',name:'Copy draft to clipboard',hint:'Copy the latest draft or workflow output'},
  {id:'link',name:'Open an approved website',hint:'Only HTTPS/HTTP links can be opened'}
];
function getStored() {
  try { let raw = NATIVE ? NATIVE.getState() : localStorage.getItem(STORE); if(raw) return JSON.parse(raw); }
  catch(e) { console.warn('State could not load',e); }
  return defaults();
}
function persist() {
  try { const json=JSON.stringify(state); if(NATIVE) NATIVE.saveState(json); else localStorage.setItem(STORE,json); }
  catch(e){ toast('Storage full. Export a backup and remove old data.'); }
}
function activity(label,detail='') { state.activity.unshift({id:uid(),label,detail,date:timestamp()}); state.activity=state.activity.slice(0,75); }
function toast(message) { const el=$('toast'); el.textContent=message; el.classList.remove('hidden'); clearTimeout(pendingToast); pendingToast=setTimeout(()=>el.classList.add('hidden'),3300); }
function modal(content) { $('modalContent').innerHTML=content; $('modalRoot').classList.remove('hidden'); }
function closeModal(){ $('modalRoot').classList.add('hidden'); $('modalContent').innerHTML=''; }
function formHeader(title){return `<div class="modal-header"><h3>${escape(title)}</h3><button class="modal-close" onclick="Voxa.closeModal()" title="Close">×</button></div>`;}
function field(label,id,val='',type='text',placeholder='') {return `<div class="form-row"><label for="${id}">${escape(label)}</label><input id="${id}" type="${type}" value="${escape(val)}" placeholder="${escape(placeholder)}"/></div>`;}
function empty(iconName,title,detail,actionHtml='') {return `<div class="empty-state"><span class="empty-icon">${iconName}</span><b>${escape(title)}</b><p>${escape(detail)}</p>${actionHtml}</div>`;}
function bridge(method,...params){try{if(NATIVE && typeof NATIVE[method]==='function'){NATIVE[method](...params);return true;}}catch(e){toast('Device action unavailable: '+e.message);}return false;}
function downloadFile(name,mime,contents){if(bridge('exportFile',name,mime,contents))return;try{const blob=new Blob([contents],{type:mime});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),2000);}catch(e){toast('Unable to export file');}}
function copy(text){if(bridge('copyText',text))return; if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(()=>toast('Copied')).catch(()=>fallbackCopy(text));}else fallbackCopy(text);}
function fallbackCopy(text){const el=document.createElement('textarea');el.value=text;document.body.appendChild(el);el.select();try{document.execCommand('copy');toast('Copied');}catch(e){toast('Use long-press to copy');}el.remove();}
function external(url){ if(!/^https?:\/\//i.test(url)){toast('Only safe web links are allowed');return;}if(!bridge('openUrl',url))window.open(url,'_blank','noopener,noreferrer'); }
function mapSearch(query){query=nl(query||$('mapQuery').value);if(!query){toast('Enter a business category and city');return;}activity('Searched Google Maps',query);persist();renderHome();if(!bridge('openMap',query))external('https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(query));}
function shareText(text){if(!text.trim()){toast('There is no text to share');return;}if(bridge('sharePost',text))return;if(navigator.share){navigator.share({text}).catch(()=>{});return;}copy(text);toast('Post copied. Open your social app to publish it.');}
function navigate(destination){const el=$('screen-'+destination);if(!el)return;screen=destination;document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));el.classList.add('active');document.querySelectorAll('.nav-btn').forEach(x=>x.classList.toggle('active',x.dataset.screen===destination||(x.dataset.screen==='more'&&['leads','commerce','assistant','settings'].includes(destination))));$('moreMenu').classList.add('hidden');$('pageScroll').scrollTop=0;render();}
function toggleMore(){$('moreMenu').classList.toggle('hidden');}
function back(){if(!$('modalRoot').classList.contains('hidden')){closeModal();return;}if(!$('moreMenu').classList.contains('hidden')){$('moreMenu').classList.add('hidden');return;}navigate('home');}
function render(){renderHome();renderSources();renderDrafts();renderTasks();renderLeads();renderCommerce();renderChat();}
function renderHome(){
  $('todayLabel').textContent=safeDate();
  const stats=[['Imported sources',state.sources.length,'in your library','inbox'],['Post drafts',state.drafts.length,'ready for review','pen'],['Custom workflows',state.tasks.length,'built by you','workflow'],['Saved leads',state.leads.length,'business contacts','map'],['Products',state.products.length,'catalog entries','grid'],['Orders',state.orders.length,'manual orders','inbox']];
  $('statGrid').innerHTML=stats.map(([label,count,hint,ico])=>`<div class="stat-card"><div class="stat-top"><span>${label}</span>${icon(ico)}</div><div class="stat-value">${count}</div><div class="stat-hint">${hint}</div></div>`).join('');
  $('activityList').innerHTML=state.activity.length?state.activity.slice(0,5).map(a=>`<div class="activity-item"><span class="activity-dot">${icon('check')}</span><div><b>${escape(a.label)}</b><small>${escape(short(a.detail,65))}</small></div><time>${fmtDate(a.date)}</time></div>`).join(''):empty('✧','A fresh start','Your imports, drafts and workflow activity will appear here.');
}
const stopwords = new Set('the and with from have your for this that are was were will there their these those what when where which how all any our you can has had its into about they them some just also want need like more much very would could should been being then than only here send please make using use facebook whatsapp instagram products product group groups chats chat people person customer customers group welcome hello thanks thank hey okay ok good great now today dear price prices quality thanks best'.split(' '));
function analyzeText(raw){
  const text=String(raw||'').slice(0,1_800_000);
  const lines=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  const senders={};let count=0;
  for(const line of lines){
    let match=line.match(/^\[.{5,40}?\]\s*([^:]{1,80}):\s*(.*)$/) || line.match(/^\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4},?\s+\d{1,2}:\d{2}(?:\s*[ap]\.?m\.?)?\s*[-–]\s*([^:]{1,80}):\s*(.*)$/i);
    if(match){const sender=match[1].trim();if(!/^[0-9: ]+$/.test(sender)){senders[sender]=(senders[sender]||0)+1;count++;}}
  }
  if(!count) count=lines.length;
  // Exclude WhatsApp timestamp/sender headers, common PII and URLs from topic mining.
  // This is basic minimization, NOT a guarantee of personal-data anonymization.
  const contentOnly=lines.map(line=>line
    .replace(/^\[.{5,40}?\]\s*[^:]{1,80}:\s*/, '')
    .replace(/^\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4},?\s+\d{1,2}:\d{2}(?:\s*[ap]\.?m\.?)?\s*[-–]\s*[^:]{1,80}:\s*/i, '')
  ).join(' ').replace(/https?:\/\/\S+/gi,' ').replace(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi,' ')
    .replace(/(?:\+?\d[\d\s().-]{7,}\d)/g,' ');
  const frequency={};
  const words=(contentOnly.toLowerCase().match(/[\p{L}\p{N}#]{3,}/gu)||[]);
  for (const word of words){let w=word.replace(/^#/,'');if(w.length<4||w.length>25||stopwords.has(w)||/^[0-9]+$/.test(w)||/^http/.test(w))continue;frequency[w]=(frequency[w]||0)+1;}
  const keywords=Object.entries(frequency).sort((a,b)=>b[1]-a[1]).slice(0,12).map(x=>x[0]);
  const prices=[...text.matchAll(/(?:\b(?:PKR|Rs\.?|AED|USD)\s*|₨|\$)\s*\d[\d,.]{0,12}/gi)].slice(0,7).map(x=>x[0]);
  const questions=(text.match(/\?/g)||[]).length;
  return {lines:lines.length,messages:count,participants:Object.keys(senders).length,keywords,priceMentions:prices.length,priceExamples:[...new Set(prices)].slice(0,3),questions,characters:text.length};
}
function sourceSummary(x){const a=x.analysis||analyzeText(x.text);const most=a.keywords.slice(0,6).join(', ');return `Analyzed ${a.messages} lines/messages from ${a.participants||'an unknown number of'} identified senders. Common topics: ${most||'not enough text to determine'}. Price references: ${a.priceMentions}. Questions: ${a.questions}. Source content was not verified; avoid publishing private names, phone numbers or unconfirmed prices.`;}
function showImport(defaultText='') {modal(formHeader('Add a content source')+`<div class="form-row"><label>Source title</label><input id="importTitle" placeholder="e.g. Fashion wholesalers — October"/></div><div class="form-row"><label>What is the source?</label><select id="importKind"><option value="WhatsApp export">WhatsApp chat export</option><option value="Shared content">Shared / copied content</option><option value="Research note">Research note</option></select></div><div class="form-row"><label>Paste text here</label><textarea id="importText" rows="11" placeholder="Paste messages, product details or your research…">${escape(defaultText)}</textarea></div><label class="field-checkbox"><input type="checkbox" id="importConsent"/> I have permission to use and analyze this content.</label><p class="form-hint">Imported text stays in this app. Use group messages responsibly and avoid publishing private details.</p><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Cancel</button><button class="btn btn-gradient" onclick="Voxa.saveImport()">Analyze & save</button></div>`);}
function saveImport(){const title=nl($('importTitle').value),text=$('importText').value.trim(),kind=$('importKind').value;if(!text){toast('Paste some text first');return;}if(!$('importConsent').checked){toast('Please confirm you have permission to use the content');return;}const source={id:uid(),title:title||'Imported content '+safeDate(),kind,text:text.slice(0,1_800_000),analysis:analyzeText(text),date:timestamp()};state.sources.unshift(source);activity('Source imported',source.title);persist();closeModal();render();navigate('sources');toast('Source saved. Analysis is ready.');}
function openImportPicker(){if(bridge('pickDocument'))return;const picker=document.createElement('input');picker.type='file';picker.accept='.txt,.csv,text/plain';picker.onchange=()=>{const file=picker.files&&picker.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>showImport(String(reader.result).slice(0,1_800_000));reader.readAsText(file);};picker.click();}
function renderSources(){const options=['<option value="">No source / use topic only</option>'].concat(state.sources.map(s=>`<option value="${escape(s.id)}">${escape(short(s.title,65))}</option>`));let selected=$('postSource').value;$('postSource').innerHTML=options.join('');$('postSource').value=selected;$('sourceCountLabel').textContent=state.sources.length+' imports';$('sourceList').innerHTML=state.sources.length?state.sources.map(s=>`<div class="list-card"><div class="list-top"><span class="list-glyph">${icon('inbox')}</span><div class="list-copy"><b>${escape(s.title)}</b><small>${escape(s.kind)} · ${fmtDate(s.date)} · ${s.analysis.messages} lines/messages</small></div><span class="tag">Analyzed</span></div><p class="card-description">${escape(short(sourceSummary(s),190))}</p><div class="card-actions"><button class="btn btn-soft" onclick="Voxa.viewSource('${s.id}')">View insights</button><button class="btn btn-soft" onclick="Voxa.useSource('${s.id}')">Create post</button><button class="icon-btn" onclick="Voxa.deleteSource('${s.id}')" title="Delete">${icon('trash')}</button></div></div>`).join(''):empty('📥','No sources added yet','Share text from WhatsApp, paste product information, or import your own chat export.','<button class="btn btn-soft small" onclick="Voxa.showImport()">Import my first source</button>');}
function viewSource(id){const s=state.sources.find(x=>x.id===id);if(!s)return;const a=s.analysis;modal(formHeader(s.title)+`<p class="help-lines">${escape(s.kind)} · ${fmtDate(s.date)}</p><div class="result-metrics"><div><strong>${a.messages}</strong><small>Lines / messages</small></div><div><strong>${a.participants}</strong><small>Known senders</small></div><div><strong>${a.questions}</strong><small>Questions</small></div></div><div class="preview-label">MOST MENTIONED WORDS</div><div class="keywords">${a.keywords.map(w=>`<span>${escape(w)}</span>`).join('')||'<small>No clear keywords</small>'}</div><div class="preview-label">RESEARCH SUMMARY</div><p class="help-lines">${escape(sourceSummary(s))}</p><div class="preview-label">SOURCE EXCERPT</div><div class="analysis-pre">${escape(short(s.text,1400))}</div><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Close</button><button class="btn btn-gradient" onclick="Voxa.useSource('${s.id}')">Draft a post</button></div>`);}
function useSource(id){closeModal();navigate('studio');$('postSource').value=id;const s=state.sources.find(x=>x.id===id);if(s&&!$('postTopic').value.trim())$('postTopic').value='Products and offers about '+s.analysis.keywords.slice(0,4).join(', ');toast('Source selected for the next draft');}
function deleteSource(id){if(!confirm('Delete this imported source?'))return;state.sources=state.sources.filter(x=>x.id!==id);activity('Source removed');persist();render();}
function makeCaption(topic,tone='professional',platform='Facebook',source=null,instructions=''){
  let title=nl(topic);const words=(source?.analysis?.keywords||[]).slice(0,4);
  if(!title)title=words.length?'Explore '+words.join(', '):'Discover something special from our collection';
  // Never invent availability, discounts, prices, features, reviews, or delivery promises.
  const intros={
    professional:'Discover our latest update',
    friendly:'Hey everyone! ✨ Here is something worth checking out',
    luxury:'A considered choice. A beautiful experience.',
    urgent:'✨ Featured update — take a look',
    urdu:'Assalam-o-Alaikum! ✨ Aap ke liye ek khaas update'
  };
  const closings={
    professional:'Interested? Send us a message for confirmed details and availability.',
    friendly:'Want to know more? Send us a DM. We would love to help! 💬',
    luxury:'Message us for further information and personalized assistance.',
    urgent:'Message us to confirm the latest details before you decide. 📩',
    urdu:'Mazeed tafseel aur availability ke liye humein message karein. 📩'
  };
  const tags=Array.from(new Set((title.match(/[\p{L}]{4,}/gu)||[]).map(t=>t.replace(/[^\p{L}]/gu,'')).filter(t=>t.length<=17&&!stopwords.has(t.toLowerCase())).slice(0,5).map(t=>'#'+t.charAt(0).toUpperCase()+t.slice(1).replace(/\s/g,''))));
  if(platform==='Instagram'||platform==='All platforms')tags.push('#ShopLocal','#SmallBusiness');
  const context=source&&words.length?`\n\nInspired by common interests in your research: ${words.join(' · ')}.`:'';
  const extra=nl(instructions)?`\n\nDetails to include or verify: ${nl(instructions)}`:'';
  return `${intros[tone]||intros.professional}\n\n${title}${context}${extra}\n\n${closings[tone]||closings.professional}\n\n${Array.from(new Set(tags)).slice(0,8).join(' ')}`.trim();
}
function makeDraft(topic,tone,platform,source=null,instructions='',silent=false){
  const post={id:uid(),topic:nl(topic)||'Source-inspired post',text:makeCaption(topic,tone,platform,source,instructions),tone,platform,sourceId:source?.id||'',date:timestamp(),status:'Draft'};
  state.drafts.unshift(post);activity('Post draft generated',post.topic);persist();if(!silent){$('postEditor').value=post.text;toast('New draft created. Check every claim before publishing.');render();}return post;
}
function generatePost(){const topic=$('postTopic').value,tone=$('postTone').value,platform=$('postPlatform').value,source=state.sources.find(s=>s.id===$('postSource').value),instructions=$('postInstructions').value;if(!topic.trim()&&!source){toast('Enter a product/topic or select a saved source');return;}makeDraft(topic,tone,platform,source,instructions);}
function saveDraft(){let text=$('postEditor').value.trim();if(!text){toast('Write or generate a post first');return;}let last=state.drafts[0];if(last&&last.text===text){toast('Draft already saved');return;}let post={id:uid(),topic:short(text.split('\n').find(x=>x.trim())||'Custom post',55),text,date:timestamp(),platform:$('postPlatform').value,tone:$('postTone').value,status:'Draft'};state.drafts.unshift(post);activity('Post draft saved',post.topic);persist();render();toast('Saved to your private draft library');}
function copyDraft(){const text=$('postEditor').value.trim();if(!text){toast('Draft is empty');return;}copy(text);}
function shareDraft(){const text=$('postEditor').value.trim();if(!text){toast('Write or generate a post first');return;}activity('Opened social share sheet','Publishing requires confirmation in the receiving app');persist();renderHome();shareText(text);}
function renderDrafts(){$('draftList').innerHTML=state.drafts.length?state.drafts.slice(0,50).map(p=>`<div class="list-card"><div class="list-top"><span class="list-glyph">${icon('pen')}</span><div class="list-copy"><b>${escape(short(p.topic||'Post draft',80))}</b><small>${escape(p.platform||'All platforms')} · ${fmtDate(p.date)}</small></div><span class="tag purple">Draft</span></div><p class="card-description">${escape(short(p.text,180))}</p><div class="card-actions"><button class="btn btn-soft" onclick="Voxa.editDraft('${p.id}')">Edit</button><button class="btn btn-primary" onclick="Voxa.quickShare('${p.id}')">Share</button><button class="icon-btn" onclick="Voxa.deleteDraft('${p.id}')" title="Delete">${icon('trash')}</button></div></div>`).join(''):empty('✍️','No drafts yet','Create promotional posts, add photos and save versions for your business.');}
function editDraft(id){const post=state.drafts.find(p=>p.id===id);if(!post)return;navigate('studio');$('postEditor').value=post.text;$('postTopic').value=post.topic;$('postPlatform').value=post.platform||'Facebook';toast('Draft loaded in editor');}
function quickShare(id){const p=state.drafts.find(x=>x.id===id);if(p)shareText(p.text);}
function deleteDraft(id){if(!confirm('Delete this post draft?'))return;state.drafts=state.drafts.filter(x=>x.id!==id);persist();render();}
function pickPhoto(){if(bridge('pickPhoto'))return;let f=document.createElement('input');f.type='file';f.accept='image/*';f.onchange=()=>{const file=f.files?.[0];if(!file)return;const r=new FileReader();r.onload=()=>updatePhoto(String(r.result));r.readAsDataURL(file);};f.click();}
function updatePhoto(data){photoPreview=data||'';const holder=$('mediaPreview');holder.innerHTML=data?`<img src="${data}" alt="Selected photo"/>`:icon('image');$('photoLabel').textContent=data?'Photo selected for social sharing':'Optional — attach when sharing';}
function clearPhoto(){photoPreview='';updatePhoto('');bridge('clearPhoto');}
function setTaskFilter(mode,button){taskFilter=mode;document.querySelectorAll('#taskFilters button').forEach(el=>el.classList.remove('selected'));button.classList.add('selected');renderTasks();}
function actionName(type){return types.find(t=>t.id===type)?.name||type;}
function renderTasks(){let list=state.tasks.filter(t=>taskFilter==='all'||t.trigger===taskFilter);$('taskList').innerHTML=list.length?list.map(t=>`<div class="list-card"><div class="list-top"><span class="list-glyph">${icon('workflow')}</span><div class="list-copy"><b>${escape(t.title)}</b><small>${t.trigger==='daily'?`Daily reminder · ${escape(t.time||'09:00')}`:'Run whenever you like'} · ${t.steps.length} steps${t.lastRun?' · Last run '+fmtDate(t.lastRun):''}</small></div><span class="tag ${t.trigger==='daily'?'gold':'purple'}">${t.trigger==='daily'?'Daily':'Manual'}</span></div><div class="workflow-steps">${t.steps.map((s,i)=>`<span>${i+1}. ${escape(actionName(s.type).replace(' latest imported source','').replace(' draft post',' post'))}</span>`).join('<span>→</span>')}</div><div class="card-actions"><button class="btn btn-soft" onclick="Voxa.openTaskModal('${t.id}')">Edit</button><button class="btn btn-gradient" onclick="Voxa.runTask('${t.id}')">▶ Run now</button><button class="icon-btn" onclick="Voxa.deleteTask('${t.id}')" title="Delete">${icon('trash')}</button></div></div>`).join(''):empty('⚡','Create your first workflow','Add your own steps. Workflows remain editable after installation.','<button class="btn btn-gradient small" onclick="Voxa.openTaskModal()">+ New workflow</button>');}
const taskTemplates=[
 {title:'WhatsApp research → Facebook post',emoji:'💬',detail:'Analyze your last imported chat, prepare a Facebook caption and review sharing',trigger:'manual',steps:[{type:'analyze',value:''},{type:'draft',value:''},{type:'share',value:''}]},
 {title:'Daily product spotlight',emoji:'✨',detail:'Get a daily reminder, compose a product post and review it before sharing',trigger:'daily',steps:[{type:'draft',value:'Featured product — add your details'},{type:'share',value:''}]},
 {title:'Discover businesses on Maps',emoji:'📍',detail:'Open a Google Maps search and then save any permitted leads manually',trigger:'manual',steps:[{type:'maps',value:'garment shops in Islamabad'}]},
 {title:'Research trend digest',emoji:'📊',detail:'Analyze imported content and save a short non-identifying report',trigger:'manual',steps:[{type:'analyze',value:''},{type:'save',value:'Weekly research digest'}]},
 {title:'Caption → clipboard',emoji:'📋',detail:'Prepare a reusable social caption and copy it for WhatsApp or your storefront',trigger:'manual',steps:[{type:'draft',value:'New product from my shop'},{type:'copy',value:''}]},
 {title:'Promote catalog product',emoji:'🛍️',detail:'Turn your latest saved product into a draft, then approve sharing',trigger:'manual',steps:[{type:'productpost',value:''},{type:'share',value:''}]},
 {title:'Cross-platform social sharing',emoji:'🌐',detail:'Compose one post and choose an installed social destination to share it',trigger:'manual',steps:[{type:'draft',value:'Business update — add your details'},{type:'share',value:''}]}
];
function openTemplates(){modal(formHeader('Ready-to-use workflows')+`<p class="help-lines">Select a starting point. Every template becomes your own fully editable task.</p><div class="template-list">${taskTemplates.map((t,i)=>`<button class="template-button" onclick="Voxa.installTemplate(${i})"><span>${t.emoji}</span><div><b>${escape(t.title)}</b><small>${escape(t.detail)}</small></div>${icon('right')}</button>`).join('')}</div>`);}
function installTemplate(index){const temp=taskTemplates[index];if(!temp)return;const newTask={id:uid(),title:temp.title,trigger:temp.trigger,time:'09:00',goal:temp.detail,steps:temp.steps.map(s=>({...s})),created:timestamp(),lastRun:null};state.tasks.unshift(newTask);if(newTask.trigger==='daily')bridge('scheduleDaily',newTask.id,newTask.title,9,0);activity('Workflow template added',temp.title);persist();closeModal();navigate('tasks');toast('Template added. Tap Edit to customize your workflow.');}
function formStepContent(s,i){return `<div class="modal-step"><div class="modal-step-head"><b>Step ${i+1}</b><button onclick="Voxa.removeStep(${i})" title="Remove step">Remove</button></div><select id="stepType-${i}" onchange="Voxa.setStepType(${i},this.value)">${types.map(x=>`<option value="${x.id}" ${s.type===x.id?'selected':''}>${escape(x.name)}</option>`).join('')}</select><small class="form-hint">${escape(types.find(t=>t.id===s.type)?.hint||'')}</small>${['draft','maps','link','save'].includes(s.type)?`<input id="stepValue-${i}" value="${escape(s.value||'')}" placeholder="${s.type==='draft'?'Post topic (optional)':s.type==='maps'?'e.g. clothing stores in Karachi':s.type==='link'?'https://example.com':'Note title (optional)'}" oninput="Voxa.setStepValue(${i},this.value)"/>`:''}</div>`;}
function refreshStepEditor(){let el=$('taskSteps');if(el)el.innerHTML=modalSteps.map(formStepContent).join('');}
function openTaskModal(id=''){
  const t=state.tasks.find(x=>x.id===id);editingTaskId=t?.id||null;modalSteps=t?JSON.parse(JSON.stringify(t.steps)):[{type:'analyze',value:''},{type:'draft',value:''},{type:'share',value:''}];
  modal(formHeader(t?'Edit workflow':'New custom workflow')+field('Workflow name','taskName',t?.title||'','text','e.g. Turn chat research into Facebook post')+`<div class="form-two"><div class="form-row"><label>Run type</label><select id="taskTrigger" onchange="Voxa.changeTrigger()"><option value="manual" ${t?.trigger!=='daily'?'selected':''}>Manual</option><option value="daily" ${t?.trigger==='daily'?'selected':''}>Daily reminder</option></select></div><div class="form-row" id="taskTimeRow"><label>Reminder time (approx.)</label><input id="taskTime" type="time" value="${escape(t?.time||'09:00')}"/></div></div><div class="form-row"><label>Instructions / goal <span class="optional">reference only</span></label><textarea id="taskGoal" rows="2" placeholder="What should this task accomplish?">${escape(t?.goal||'')}</textarea></div><div class="section-heading" style="margin:12px 0"><h2>Workflow steps</h2><span class="subtitle">Run from top to bottom</span></div><div id="taskSteps"></div><button class="btn btn-soft full" onclick="Voxa.addStep()">${icon('plus')} Add another step</button><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Cancel</button><button class="btn btn-gradient" onclick="Voxa.saveTask()">${t?'Save changes':'Create workflow'}</button></div><p class="micro-disclaimer">Workflow actions are preset safe building blocks. Completely new device abilities require an app update. Daily tasks remind you to open and run the workflow.</p>`);
  changeTrigger();refreshStepEditor();
}
function changeTrigger(){const el=$('taskTimeRow');if(el)el.style.opacity=$('taskTrigger').value==='daily'?'1':'.4';}
function addStep(){if(modalSteps.length>=12){toast('Maximum 12 steps per workflow');return;}modalSteps.push({type:'draft',value:''});refreshStepEditor();}
function removeStep(i){if(modalSteps.length<=1){toast('At least one step is required');return;}modalSteps.splice(i,1);refreshStepEditor();}
function setStepType(i,type){modalSteps[i].type=type;modalSteps[i].value='';refreshStepEditor();}
function setStepValue(i,value){modalSteps[i].value=value;}
function saveTask(){const title=nl($('taskName').value),trigger=$('taskTrigger').value,time=$('taskTime').value||'09:00',goal=$('taskGoal').value.trim();if(title.length<3){toast('Choose a workflow name of at least 3 characters');return;}if(!modalSteps.length){toast('Add at least one step');return;}if(modalSteps.some(s=>s.type==='link'&&!/^https?:\/\//i.test(s.value))){toast('Website steps need an HTTP or HTTPS URL');return;}
  const existing=state.tasks.find(t=>t.id===editingTaskId);
  if(existing)bridge('cancelDaily',existing.id);
  const task={id:existing?.id||uid(),title,trigger,time,goal,steps:modalSteps.map(x=>({...x})),lastRun:existing?.lastRun||null,created:existing?.created||timestamp()};
  if(existing)state.tasks=state.tasks.map(x=>x.id===existing.id?task:x);else state.tasks.unshift(task);
  if(trigger==='daily'){const [hour,minute]=time.split(':').map(Number);bridge('scheduleDaily',task.id,task.title,hour,minute);}
  activity(existing?'Workflow updated':'Workflow created',title);persist();closeModal();navigate('tasks');toast(trigger==='daily'?'Workflow saved. Daily reminder set where supported.':'Custom workflow saved and ready to run.');
}
function deleteTask(id){const task=state.tasks.find(t=>t.id===id);if(!task||!confirm('Remove workflow "'+task.title+'"?'))return;bridge('cancelDaily',id);state.tasks=state.tasks.filter(x=>x.id!==id);activity('Workflow removed',task.title);persist();render();}
function runTask(id){
  if(workflowRunLock){toast('A workflow is already running');return;}
  const task=state.tasks.find(t=>t.id===id);if(!task)return;workflowRunLock=true;
  const ctx={source:state.sources[0]||null,draft:state.drafts[0]||null,summary:'',actions:[],issues:[]};
  try{
    task.steps.forEach(step=>{
      if(step.type==='productpost'){
        const product=state.products[0];if(!product){ctx.issues.push('Add a product to your catalog first');return;}
        const description=[product.name,product.description,product.price>0?'PKR '+product.price:''].filter(Boolean).join(' — ');
        ctx.draft=makeDraft(description,'professional','Facebook',null,'',true);$('postEditor').value=ctx.draft.text;ctx.actions.push('Created catalog product post');
      }else if(step.type==='analyze'){
        if(!ctx.source){ctx.issues.push('No imported source is available to analyze');return;}
        ctx.summary=sourceSummary(ctx.source);ctx.actions.push('Analyzed '+ctx.source.title);
      }else if(step.type==='draft'){
        const topic=nl(step.value||task.goal||'');
        if(!topic&&!ctx.source){ctx.issues.push('Add a topic to the Draft step or import a source');return;}
        ctx.draft=makeDraft(topic,'professional','Facebook',ctx.source,'',true);
        $('postEditor').value=ctx.draft.text;
        ctx.actions.push('Created post draft');
      }else if(step.type==='save'){
        if(!ctx.summary&&!ctx.draft){ctx.issues.push('Nothing to save yet');return;}
        let content=ctx.summary||ctx.draft.text;
        const s={id:uid(),title:nl(step.value)||'Workflow research note',kind:'Research note',text:content,analysis:analyzeText(content),date:timestamp()};
        state.sources.unshift(s);ctx.actions.push('Saved research note');
      }else if(step.type==='maps'){
        const query=nl(step.value||task.goal);
        if(!query){ctx.issues.push('Maps step requires a search query');return;}
        mapSearch(query);ctx.actions.push('Opened Google Maps search');
      }else if(step.type==='share'){
        if(!ctx.draft){ctx.issues.push('No available draft to share');return;}
        shareText(ctx.draft.text);ctx.actions.push('Opened share chooser (approval required)');
      }else if(step.type==='copy'){
        if(!ctx.draft&&!ctx.summary){ctx.issues.push('Nothing to copy yet');return;}
        copy(ctx.draft?.text||ctx.summary);ctx.actions.push('Copied output');
      }else if(step.type==='link'){
        external(step.value||'');ctx.actions.push('Opened website');
      }
    });
    task.lastRun=timestamp();activity('Workflow run',task.title+' · '+ctx.actions.length+' actions');persist();render();
    let result=`Completed ${ctx.actions.length} action(s):\n\n${ctx.actions.map(x=>'✓ '+x).join('\n')||'No action was completed.'}`;
    if(ctx.issues.length)result+=`\n\nNeeds your attention:\n${ctx.issues.map(x=>'• '+x).join('\n')}`;
    if(ctx.draft)result+='\n\nYour post is saved in the Content Studio for editing and review.';
    modal(formHeader('Workflow result')+`<div class="analysis-pre">${escape(result)}</div><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Close</button><button class="btn btn-gradient" onclick="Voxa.closeModal();Voxa.navigate('${ctx.draft?'studio':'tasks'}')">${ctx.draft?'Review post':'My workflows'}</button></div>`);
  }catch(e){toast('Workflow issue: '+e.message);}finally{workflowRunLock=false;}
}
function openLeadModal(id=''){
  const x=state.leads.find(l=>l.id===id);editingLeadId=x?.id||null;
  modal(formHeader(x?'Edit business contact':'Add business contact')+field('Business name *','leadName',x?.name||'','text','e.g. ABC Fabrics')+`<div class="form-two">${field('Category','leadCategory',x?.category||'','text','Clothing store')}${field('City / area','leadCity',x?.city||'','text','Islamabad')}</div>`+field('Phone number','leadPhone',x?.phone||'','tel','+92 ...')+field('Website / Google Maps link','leadWebsite',x?.website||'','url','https://...')+field('Address','leadAddress',x?.address||'','text','Street, area, city')+`<div class="form-row"><label>Notes</label><textarea id="leadNotes" rows="3" placeholder="Source, follow-up date, product interest…">${escape(x?.notes||'')}</textarea></div><label class="field-checkbox"><input id="leadPermission" type="checkbox" ${x?'checked':''}/> I am authorized to save this contact information.</label><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Cancel</button><button class="btn btn-gradient" onclick="Voxa.saveLead()">Save business</button></div>`);
}
function saveLead(){const name=nl($('leadName').value),phone=nl($('leadPhone').value),city=nl($('leadCity').value);if(!name){toast('Enter a business name');return;}if(!$('leadPermission').checked){toast('Confirm you can save this contact');return;}const previous=state.leads.find(l=>l.id===editingLeadId);const x={id:previous?.id||uid(),name,phone,city,category:nl($('leadCategory').value),website:nl($('leadWebsite').value),address:nl($('leadAddress').value),notes:$('leadNotes').value.trim(),date:previous?.date||timestamp()};if(previous)state.leads=state.leads.map(l=>l.id===previous.id?x:l);else state.leads.unshift(x);activity(previous?'Lead updated':'Lead saved',name);persist();closeModal();render();toast('Business contact saved locally');}
function renderLeads(){const term=($('leadSearch').value||'').toLowerCase();const list=state.leads.filter(l=>[l.name,l.category,l.city,l.phone,l.address].join(' ').toLowerCase().includes(term));$('leadList').innerHTML=list.length?list.map(l=>`<div class="list-card"><div class="list-top"><span class="list-glyph">${icon('map')}</span><div class="list-copy"><b>${escape(l.name)}</b><small>${escape([l.category,l.city].filter(Boolean).join(' · ')||'Business contact')} · ${fmtDate(l.date)}</small></div></div>${l.phone?`<div class="lead-contact">☎ ${escape(l.phone)}</div>`:''}${l.address?`<div class="lead-contact">⌖ ${escape(l.address)}</div>`:''}${l.notes?`<p class="card-description">${escape(short(l.notes,160))}</p>`:''}<div class="card-actions">${l.website&&/^https?:\/\//.test(l.website)?`<button class="btn btn-soft" onclick="Voxa.openLeadSite('${l.id}')">Open link</button>`:''}<button class="btn btn-soft" onclick="Voxa.openLeadModal('${l.id}')">Edit</button><button class="icon-btn" onclick="Voxa.deleteLead('${l.id}')" title="Delete">${icon('trash')}</button></div></div>`).join(''):empty('📍','No saved businesses','Open Maps to research shops and manually save authorized contact details.');}
function openLeadSite(id){const l=state.leads.find(x=>x.id===id);if(l)external(l.website);}
function deleteLead(id){if(!confirm('Delete this business contact?'))return;state.leads=state.leads.filter(x=>x.id!==id);persist();render();}
function exportLeads(){const cols=['Name','Category','Phone','City','Address','Website','Notes','Saved'];const csvCell=v=>'"'+String(v??'').replace(/"/g,'""')+'"';const rows=state.leads.map(l=>[l.name,l.category,l.phone,l.city,l.address,l.website,l.notes,l.date].map(csvCell).join(','));downloadFile('voxaflow-business-leads.csv','text/csv;charset=utf-8','\uFEFF'+cols.join(',')+'\r\n'+rows.join('\r\n'));}
function openProductModal(id=''){
  const x=state.products.find(p=>p.id===id);
  modal(formHeader(x?'Edit catalog product':'Add catalog product')+field('Product / service name *','productName',x?.name||'','text','e.g. Embroidered lawn suit')+`<div class="form-two">${field('Price in PKR','productPrice',x?.price||'','number','2499')}${field('Stock quantity','productStock',x?.stock??'','number','10')}</div>`+field('Category','productCategory',x?.category||'','text','Clothing')+`<div class="form-row"><label>Description / verified details</label><textarea id="productDescription" rows="4" placeholder="Size, material, colors, features, delivery terms…">${escape(x?.description||'')}</textarea></div><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Cancel</button><button class="btn btn-gradient" onclick="Voxa.saveProduct('${x?.id||''}')">Save product</button></div>`);
}
function saveProduct(id){const name=nl($('productName').value);if(!name){toast('A product name is required');return;}const price=Number($('productPrice').value||0),stock=Number($('productStock').value||0);if(!Number.isFinite(price)||price<0||!Number.isFinite(stock)||stock<0){toast('Price and stock must be zero or above');return;}const existing=state.products.find(p=>p.id===id);const product={id:existing?.id||uid(),name,price,stock:Math.floor(stock),category:nl($('productCategory').value),description:$('productDescription').value.trim(),date:existing?.date||timestamp()};if(existing)state.products=state.products.map(p=>p.id===id?product:p);else state.products.unshift(product);activity(existing?'Product updated':'Product added',name);persist();closeModal();render();toast('Saved to your private product catalog');}
function deleteProduct(id){if(!confirm('Delete this catalog product? Existing orders will remain as historical records.'))return;state.products=state.products.filter(x=>x.id!==id);persist();render();}
function postProduct(id){const p=state.products.find(x=>x.id===id);if(!p)return;const description=[p.name,p.description,p.price>0?'Price: PKR '+p.price:''].filter(Boolean).join(' — ');navigate('studio');$('postTopic').value=description;makeDraft(description,'professional','Facebook');toast('Product draft created. Check the details before publishing.');}
function openOrderModal(id=''){
  const x=state.orders.find(o=>o.id===id);
  const options=['<option value="">Select product or enter a custom item</option>'].concat(state.products.map(p=>`<option value="${escape(p.id)}" ${p.id===x?.productId?'selected':''}>${escape(p.name)}</option>`)).join('');
  modal(formHeader(x?'Edit order':'Record an order')+field('Customer reference / order name *','orderCustomer',x?.customer||'','text','Customer alias or order #')+`<div class="form-row"><label>Catalog product</label><select id="orderProduct" onchange="Voxa.orderProductChanged()">${options}</select></div>`+field('Item name','orderItem',x?.item||'','text','Enter the product name')+`<div class="form-two">${field('Quantity','orderQuantity',x?.quantity??1,'number','1')}${field('Unit price in PKR','orderPrice',x?.unitPrice??0,'number','2499')}</div>`+`<div class="form-row"><label>Order status</label><select id="orderStatus">${['New','Confirmed','Shipped','Completed','Cancelled'].map(st=>`<option ${st===x?.status?'selected':''}>${st}</option>`).join('')}</select></div><div class="form-row"><label>Internal notes</label><textarea id="orderNotes" rows="2" placeholder="Payment status, delivery notes or follow-up…">${escape(x?.notes||'')}</textarea></div><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Cancel</button><button class="btn btn-gradient" onclick="Voxa.saveOrder('${x?.id||''}')">Save order</button></div>`);
}
function orderProductChanged(){const prod=state.products.find(p=>p.id===$('orderProduct').value);if(prod){$('orderItem').value=prod.name;$('orderPrice').value=prod.price;}}
function saveOrder(id){const customer=nl($('orderCustomer').value),item=nl($('orderItem').value),quantity=Number($('orderQuantity').value||0),unitPrice=Number($('orderPrice').value||0);if(!customer||!item){toast('Enter the customer reference and item name');return;}if(!Number.isInteger(quantity)||quantity<1||quantity>100000||!Number.isFinite(unitPrice)||unitPrice<0){toast('Enter a valid quantity and nonnegative price');return;}const old=state.orders.find(o=>o.id===id);const order={id:old?.id||uid(),customer,item,productId:$('orderProduct').value,quantity,unitPrice,status:$('orderStatus').value,notes:$('orderNotes').value.trim(),date:old?.date||timestamp()};if(old)state.orders=state.orders.map(o=>o.id===id?order:o);else state.orders.unshift(order);activity(old?'Order updated':'Order recorded',order.customer+' · '+order.item);persist();closeModal();render();toast('Order saved locally');}
function deleteOrder(id){if(!confirm('Remove this order record?'))return;state.orders=state.orders.filter(o=>o.id!==id);persist();render();}
function renderCommerce(){const total=state.orders.filter(o=>o.status==='Completed').reduce((sum,o)=>sum+o.quantity*o.unitPrice,0);const pending=state.orders.filter(o=>!['Completed','Cancelled'].includes(o.status)).length;const low=state.products.filter(p=>p.stock<=3).length;const metrics=[['Catalog',state.products.length,'grid'],['Open orders',pending,'inbox'],['Low stock',low,'bell'],['Completed sales',`₨${Math.round(total).toLocaleString('en-PK')}`,'check']];$('commerceStats').innerHTML=metrics.map(([label,count,ico])=>`<div class="stat-card"><div class="stat-top"><span>${label}</span>${icon(ico)}</div><div class="stat-value commerce-value">${escape(count)}</div></div>`).join('');$('productList').innerHTML=state.products.length?state.products.map(p=>`<div class="list-card"><div class="list-top"><span class="list-glyph">${icon('grid')}</span><div class="list-copy"><b>${escape(p.name)}</b><small>${escape(p.category||'Product')} · ${p.price>0?'PKR '+p.price.toLocaleString('en-PK'):'Price not set'}</small></div><span class="tag ${p.stock<=3?'gold':''}">${p.stock} stock</span></div><p class="card-description">${escape(short(p.description||'Add product details to create better posts.',155))}</p><div class="card-actions"><button class="btn btn-soft" onclick="Voxa.openProductModal('${p.id}')">Edit</button><button class="btn btn-gradient" onclick="Voxa.postProduct('${p.id}')">Draft post</button><button class="icon-btn" onclick="Voxa.deleteProduct('${p.id}')" title="Delete">${icon('trash')}</button></div></div>`).join(''):empty('🛍️','Your catalog is empty','Add your first product to organize prices, stock and promotions.');$('orderList').innerHTML=state.orders.length?state.orders.map(o=>`<div class="list-card"><div class="list-top"><span class="list-glyph">${icon('inbox')}</span><div class="list-copy"><b>${escape(o.customer)} · ${escape(o.item)}</b><small>${o.quantity} × PKR ${o.unitPrice.toLocaleString('en-PK')} · ${fmtDate(o.date)}</small></div><span class="tag ${o.status==='Completed'?'':'gold'}">${escape(o.status)}</span></div><div class="card-actions"><button class="btn btn-soft" onclick="Voxa.openOrderModal('${o.id}')">View / update</button><button class="icon-btn" onclick="Voxa.deleteOrder('${o.id}')" title="Delete">${icon('trash')}</button></div></div>`).join(''):empty('📦','No orders recorded','Manually track incoming orders and their progress.');}
function exportOrders(){const columns=['Customer','Item','Quantity','Unit price (PKR)','Total (PKR)','Status','Notes','Date'];const cell=v=>'"'+String(v??'').replace(/"/g,'""')+'"';const rows=state.orders.map(o=>[o.customer,o.item,o.quantity,o.unitPrice,o.quantity*o.unitPrice,o.status,o.notes,o.date].map(cell).join(','));downloadFile('voxaflow-order-report.csv','text/csv;charset=utf-8','\uFEFF'+columns.join(',')+'\r\n'+rows.join('\r\n'));}
function renderChat(){const holder=$('conversation');holder.innerHTML=state.chat.slice(-55).map(m=>`<div class="bubble ${m.who==='user'?'user':'assistant'}">${escape(m.text)}</div>`).join('');holder.scrollTop=holder.scrollHeight;}
function reply(text){state.chat.push({who:'assistant',text});state.chat=state.chat.slice(-65);persist();renderChat();if(state.settings.speak)bridge('speak',text.slice(0,1200),state.settings.language);return text;}
function sayCommand(text){const input=String(text||'').trim();if(!input)return;state.chat.push({who:'user',text:input});persist();renderChat();const t=input.toLowerCase();const mentioned=()=>[...state.tasks].find(task=>t.includes(task.title.toLowerCase()));
  // Deliberately finite set of interpreted actions. No arbitrary code, credentials, or hidden surveillance.
  if(/(run|start|execute|چلاؤ|شروع).*(workflow|task|ورک فلو|ٹاسک)/i.test(t)){
    const task=mentioned()||state.tasks[0];if(task){reply('Opening your workflow: '+task.title+'. I will run only its saved steps.');runTask(task.id);}else{reply('No workflows saved yet. Opening the workflow builder.');navigate('tasks');openTaskModal();}return;
  }
  if(/(new task|add task|workflow|automation|ٹاسک|ورک فلو)/i.test(t)&&!/(show|list|how many|count)/i.test(t)) {reply('Opening the custom workflow builder. Pick a trigger and the steps you want to run.');navigate('tasks');openTaskModal();return;}
  if(/(maps|find|search|shops|business|stores|دکان|دکانیں|تلاش)/i.test(t)&&/(shops|business|stores|maps|دکان|دکانیں|مارکیٹ|find)/i.test(t)){
    let query=input.replace(/^(please\s+)?(find|search(?:\s+for)?|show|locate|google\s+maps)\s*/i,'').replace(/^me\s+/i,'').trim();
    query=query||'shops near me';$('mapQuery').value=query;navigate('leads');reply('I prepared your Google Maps search for “'+query+'”. Opening Maps; listings are not scraped or automatically saved.');mapSearch(query);return;
  }
  if(/(order|orders|inventory|catalog|stock|products|product list|storefront)/i.test(t)&&!/(facebook|instagram|post|caption)/i.test(t)){navigate('commerce');reply(`You have ${state.products.length} catalog product(s) and ${state.orders.length} tracked order(s). Opening the Commerce Hub.`);return;}
  if(/(analy[sz]e|summary|summari[sz]e|insights|analysis|تجزیہ|خلاصہ)/i.test(t)){
    if(!state.sources.length){reply('You have not imported any content yet. Share text from WhatsApp or import a chat .txt/.zip file into Sources first.');navigate('sources');return;}
    const s=state.sources[0];reply('Latest source — '+s.title+'\n\n'+sourceSummary(s));navigate('sources');return;
  }
  if(/(facebook|instagram|whatsapp|post|caption|write|create|draft|اشتہار|پوسٹ)/i.test(t)){
    const platform=/instagram/i.test(t)?'Instagram':/whatsapp/i.test(t)?'WhatsApp':'Facebook';
    let topic=input.replace(/^(can you\s+|please\s+|make\s+me\s+|create\s+|write\s+|draft\s+|generate\s+|make\s+|a\s+|an\s+|for\s+)+/ig,'').replace(/^(a\s+)?(facebook|instagram|whatsapp)\s+(post|caption)\s*(about|for|on)?\s*/i,'').trim();
    if(!topic||/^(post|caption|facebook|instagram|whatsapp)$/i.test(topic))topic='';
    navigate('studio');$('postPlatform').value=platform;$('postTopic').value=topic;
    if(topic){generatePost();reply('I created a '+platform+' draft based on your words. Review it in the Content Studio before sharing.');}else reply('The Content Studio is open. Tell me the product or offer you want to write about, then generate a draft.');return;
  }
  if(/(contacts|leads|phone numbers|businesses)/i.test(t)) {navigate('leads');reply('You currently have '+state.leads.length+' saved business contact(s). Opening your lead list.');return;}
  if(/(sources|imports|chats|messages)/i.test(t)) {navigate('sources');reply('You have '+state.sources.length+' imported source(s). I can analyze text you share with me.');return;}
  if(/(how many|statistics|dashboard|report|overview|count)/i.test(t)) {navigate('home');reply(`Your workspace has ${state.sources.length} source(s), ${state.drafts.length} saved post(s), ${state.tasks.length} workflow(s), ${state.leads.length} business lead(s), ${state.products.length} product(s) and ${state.orders.length} order(s).`);return;}
  if(/(help|what can you do|commands|مدد)/i.test(t)) {reply('Try: “Find clothing shops in Lahore”, “Create a Facebook post for summer dresses”, “Analyze my latest chat”, “Add a new workflow”, “Run my workflow”, or “Show my leads”.\n\nI handle these known commands locally. I do not read WhatsApp in the background or publish without approval.');return;}
  reply('I can help with research imports, business contacts, social post drafts, custom workflows and Google Maps searches. Try “help” to see the commands I understand. For complex open-ended questions, a separate optional on-device AI model would be needed.');
}
function sendCommand(){const input=$('commandInput');let cmd=input.value.trim();if(!cmd)return;input.value='';sayCommand(cmd);}
function submitCommand(cmd){navigate('assistant');sayCommand(cmd);}
function clearConversation(){state.chat=defaults().chat;persist();renderChat();}
function startVoice(){if(bridge('voiceInput',state.settings.language))return;const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SpeechRecognition){toast('Speech recognition not available. Type a command instead.');return;}const rec=new SpeechRecognition();rec.lang=state.settings.language==='ur'?'ur-PK':'en-PK';rec.interimResults=false;rec.onresult=e=>sayCommand(e.results[0][0].transcript);rec.onerror=()=>toast('Voice input was unsuccessful');try{rec.start();toast('Listening…');}catch(e){toast('Microphone unavailable');}}
function saveSettings(){state.settings={language:$('settingLanguage').value,theme:$('settingTheme').value,speak:$('settingSpeak').checked};document.documentElement.classList.toggle('light',state.settings.theme==='light');persist();}
function syncSettingsUI(){$('settingLanguage').value=state.settings.language||'en';$('settingTheme').value=state.settings.theme||'dark';$('settingSpeak').checked=!!state.settings.speak;document.documentElement.classList.toggle('light',state.settings.theme==='light');}
function exportBackup(){downloadFile('VoxaFlow-backup-'+new Date().toISOString().slice(0,10)+'.json','application/json',JSON.stringify(state,null,2));toast('Choose where to save your backup. Keep it private.');}
function openBackupImport(){modal(formHeader('Restore a backup')+`<p class="help-lines">Paste a VoxaFlow JSON backup below. Restoring replaces the current saved data. Export your current backup first if needed.</p><div class="form-row"><label>Backup JSON</label><textarea id="backupJson" rows="10" placeholder='{"schema":1,"sources":[],…}'></textarea></div><div class="modal-actions"><button class="btn btn-soft" onclick="Voxa.closeModal()">Cancel</button><button class="btn btn-gradient" onclick="Voxa.restoreBackup()">Restore backup</button></div>`);}
function restoreBackup(){try{const data=JSON.parse($('backupJson').value);if(!data||!Array.isArray(data.sources)||!Array.isArray(data.drafts)||!Array.isArray(data.tasks)||!Array.isArray(data.leads)||typeof data.settings!=='object')throw Error('Not a valid VoxaFlow backup');if(!confirm('Replace all current data with this backup?'))return;for(const old of state.tasks)bridge('cancelDaily',old.id);state={...defaults(),...data,chat:Array.isArray(data.chat)?data.chat:defaults().chat,activity:Array.isArray(data.activity)?data.activity:[],settings:{...defaults().settings,...data.settings}};persist();syncSettingsUI();closeModal();render();toast('Backup restored. Recreate daily reminders if needed.');}catch(e){toast('Restore failed: '+e.message);}}
function clearAll(){if(!confirm('This permanently deletes ALL VoxaFlow data on this device. Continue?'))return;if(!confirm('Final confirmation: erase saved sources, drafts, contacts and workflows?'))return;for(const t of state.tasks)bridge('cancelDaily',t.id);state=defaults();persist();syncSettingsUI();render();navigate('home');toast('All locally saved data erased');}
function receivedFromExternal(text){if(!text)return;navigate('sources');showImport(String(text).slice(0,1_800_000));$('importKind').value='Shared content';toast('Shared text received. Review and save it.');}
function nativeEvent(ev){if(!ev||!ev.type)return;if(ev.type==='shared')receivedFromExternal(ev.text);else if(ev.type==='import'){if(String(ev.text).startsWith('No text file found')){toast(ev.text);return;}navigate('sources');showImport(ev.text);toast('File loaded. Check the source and save it.');}else if(ev.type==='voice'){navigate('assistant');sayCommand(ev.text);}else if(ev.type==='photo'){updatePhoto(ev.text);}else if(ev.type==='error')toast(ev.text);}
window.VoxaNativeEvent = nativeEvent;
const Voxa={navigate,toggleMore,back,closeModal,showImport,saveImport,openImportPicker,viewSource,useSource,deleteSource,
  generatePost,saveDraft,copyDraft,shareDraft,editDraft,quickShare,deleteDraft,pickPhoto,clearPhoto,
  setTaskFilter,openTaskModal,openTemplates,installTemplate,changeTrigger,addStep,removeStep,setStepType,setStepValue,saveTask,runTask,deleteTask,
  mapSearch:()=>mapSearch(),openLeadModal,saveLead,renderLeads,openLeadSite,deleteLead,exportLeads,openProductModal,saveProduct,deleteProduct,postProduct,openOrderModal,orderProductChanged,saveOrder,deleteOrder,exportOrders,
  sendCommand,submitCommand,clearConversation,startVoice,saveSettings,exportBackup,openBackupImport,restoreBackup,clearAll,
  receiveShared:receivedFromExternal,
  // Expose a minimal non-mutating self-test surface to validate core actions in the demo.
  getCounts:()=>({sources:state.sources.length,drafts:state.drafts.length,tasks:state.tasks.length,leads:state.leads.length,products:state.products.length,orders:state.orders.length})
};
window.Voxa=Voxa;
function boot(){state=getStored();if(!state||!Array.isArray(state.sources)||!Array.isArray(state.tasks))state=defaults();state.settings={...defaults().settings,...(state.settings||{})};for(const k of ['sources','drafts','tasks','leads','products','orders','activity','chat'])if(!Array.isArray(state[k]))state[k]=defaults()[k];syncSettingsUI();render();navigate('home');}
boot();
})();
