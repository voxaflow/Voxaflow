@echo off
REM Convenience Gradle bootstrap (not the stock Gradle wrapper)
where gradle >nul 2>&1
if %ERRORLEVEL% == 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set "ROOT=%USERPROFILE%\.gradle\voxaflow-bootstrap"
set "GRADLE=%ROOT%\gradle-8.10.2\bin\gradle.bat"
if not exist "%GRADLE%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $p='%ROOT%'; New-Item -Force -ItemType Directory $p | Out-Null; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.10.2-bin.zip' -OutFile (Join-Path $p 'gradle.zip'); Expand-Archive -Force (Join-Path $p 'gradle.zip') -DestinationPath $p"
)
call "%GRADLE%" %*
