# VoxaFlow — Private Android Commerce Assistant

**Status:** Functional first-version Android Studio source project. It has NOT been compiled into an APK or verified on a real Android device in this environment. The included `smoke-test.js` tests browser-side application logic. A ready-to-open standalone HTML preview is available separately as `VoxaFlow-demo.html`.

VoxaFlow is a mobile-first social-commerce organizer. It runs its interface and saved records on your phone, without an app-store listing, a database server, accounts, or an ongoing subscription. Online actions still need internet. Every external publishing action requires approval in the receiving app.

## Included working functionality

| Area | Functionality |
| --- | --- |
| Home | Dashboard counts, quick actions and recent activity |
| Sources | Paste text, receive text via Android share, import WhatsApp `.txt` or `.zip` exports, keyword analysis, safe summaries, question and price counts |
| Content Studio | Offline template-based caption drafts in several styles, source-inspired ideas, save/edit/delete posts, attach a device photo, share to installed social apps |
| Workflows | Create, edit, delete and run unlimited custom tasks; eight supported action blocks, up to 12 steps per task, seven prebuilt editable task templates |
| Scheduling | Daily approximate device notification to open/review workflows; NOT unattended background social posting |
| Leads | Google Maps keyword search, manually save/edit/search your permitted business contacts, export CSV |
| Commerce hub | Manual product catalog with prices and stock, editable orders and status, completed-order totals, CSV order report, one-tap product-to-post drafts |
| Assistant | English/Urdu speech-recognition integration, known voice/text commands, optional text-to-speech if supported on the phone |
| Privacy | Locally saved state, explicit confirmation before importing other people's text, JSON backup/restore, erase-local-data option |
| Design | Custom generated high-resolution gradient icon, responsive premium dark/light UI, Android-style bottom navigation |

## Important limitations — do not skip

1. **Not a general offline LLM:** The included assistant is a command parser; it understands a documented set of English-language phrases and some Urdu cues. Urdu recognition quality depends on the device. Post generation is a template composer, not a neural language model. A real offline LLM would require additional downloadable models and significant phone RAM/storage.
2. **WhatsApp:** There is **no automatic reading of private WhatsApp groups/channels**, hidden monitoring, or channel auto-posting. Import text your account is authorized to share using WhatsApp's share/export features. Private messages and other people's personal details should not be republished without appropriate permission.
3. **Facebook/Instagram:** Sharesheet handoff lets you review and send content to compatible apps. It **does not guarantee** that a destination supports publishing to every Page, group, profile, Story or Channel. Real unattended Facebook Page / professional Instagram publishing requires Meta app registration, platform permissions and supported integration; such accounts are NOT connected in this project.
4. **Google Maps:** The app opens Maps queries and lets you manually record independently permitted contact information. It does **not** scrape or bulk-export Google Maps businesses. A Google Places API connector, billing and compliance would be required for app-mediated business discovery.
5. **Daily task:** A native Android inexact alarm reminds you to *open and run* the configured workflow. The phone may delay or suppress reminders under battery-saving rules. It does not bypass app restrictions or auto-publish.
6. **Backups:** Information is held in app-private Android preferences and can be exported as an unencrypted JSON file. Do not share unencrypted backups containing sensitive chat details. The app does not provide end-to-end encryption or authentication.
7. **Commerce:** Products, stock and orders are manually maintained and are not synchronized with Facebook Shops, WhatsApp, Instagram or payment providers. Sales totals are calculated only from manually marked Completed orders; completing an order does not automatically reduce stock.
8. **Voice:** Uses Android's available speech-recognition service. **Offline voice processing is not guaranteed**; installed service settings may send audio to a provider. Optional device TTS voices may need downloads.
9. **Expandable tasks:** You can add as many **configured workflows** as storage allows from supported building blocks after installation. Adding entirely new abilities (such as supported API publishing or on-device neural AI) needs an application update and potentially external platform approval.

## Build an APK with Android Studio

Requirements: Android Studio, Android SDK Platform 35, a JDK 17+ runtime, and internet access **for this one-time compilation**. Source is Java + local HTML/CSS/JavaScript with no Android third-party runtime dependencies.

1. Extract `VoxaFlow-Android.zip` on your computer.
2. Open the `VoxaFlow-Android` directory as an existing project in Android Studio.
3. Use Gradle **8.10.2** and Android Gradle Plugin **8.8.2** (declared in build files). If Android Studio requests the Gradle wrapper, run `gradle wrapper --gradle-version 8.10.2` once after installing Gradle, or use the supplied optional bootstrap `gradlew` / `gradlew.bat` command in a terminal. Those bootstrap scripts download Gradle from its official distribution if not installed.
4. Install Android SDK Platform 35 if Android Studio asks.
5. Run `gradle assembleDebug` or `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
6. Your output will be at `app/build/outputs/apk/debug/app-debug.apk` **on your build computer**. Copy that file to your phone and open it to install. Android may require permission to install apps from that file manager/browser.
7. Launch VoxaFlow, create a workflow, and import a permitted WhatsApp chat export to test it.

**Alternative without a computer:** A GitHub Actions build workflow is provided in `.github/workflows/android-debug-apk.yml`; uploading this source to a GitHub repository can build a debug APK in GitHub Actions. This uses cloud CI **only to create the APK**, not as a server for the phone application. You control whether to use GitHub, and uploading source to a public repository would make it public.

## Modules and technical structure

- `app/src/main/assets/index.html` — complete app screens, accessibility labels and navigation.
- `app/src/main/assets/style.css` — premium responsive dark/light visual design.
- `app/src/main/assets/app.js` — local state store, imports, analysis, composer, task engine, contacts, products, orders, commands and backup.
- `app/src/main/java/com/voxaflow/commerce/MainActivity.java` — Android WebView host, system speech recognizer, sharesheet, document/photo pickers, CSV/JSON export, Google Maps links, reminders.
- `app/src/main/java/com/voxaflow/commerce/ReminderReceiver.java` — daily reminder notifications.
- `app/src/main/res/mipmap-*/ic_launcher.png` — custom app icon sized for multiple display densities.
- `smoke-test.js` — browser logic smoke tests. Run `node smoke-test.js` (Node.js 18+).

## Suggested next phases

- Meta OAuth integration for **eligible Facebook Pages and professional Instagram accounts**. May need backend security, app review, approved permissions and approved content media hosting.
- An optional on-device LLM + offline speech-recognition package if the phone has suitable RAM and storage.
- Permission-based customer conversation tracking through supported **WhatsApp Business Platform** message webhooks, not arbitrary WhatsApp group scraping. This generally requires a public HTTPS callback or approved intermediary.
- Licensed, quota-limited Google Places API search with explicit data-retention policies.
- Advanced reminders, scheduled content calendar, SKU/product catalog, order tracker, sales charts, and multilingual support.

## Security & privacy considerations

JavaScript is loaded only from bundled `file:///android_asset/index.html`. External links open in Android's browser. WebView does not allow file-to-web cross-origin access. The local JavaScript bridge is exposed only to bundled content. No analytics, ads, account credentials or external data endpoint is included. Exported JSON and CSV files are outside the app's private storage; keep them secure.

## Official platform documentation

- Android Sharesheet: https://developer.android.com/develop/ui/compose/sharing/send
- Meta WhatsApp Business Platform: https://www.postman.com/meta/whatsapp-business-platform/overview
- Meta Instagram API: https://www.postman.com/meta/instagram/documentation/6yqw8pt/instagram-api
- WhatsApp Channels: https://faq.whatsapp.com/809740894165112
- Google Maps Platform policies: https://developers.google.com/maps/terms

---

VoxaFlow v1.0 — a transparent local-first prototype. No credentials are required or embedded.
